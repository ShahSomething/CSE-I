// Example: Virtual Function and Polymorphism example
// Author: Engr. Sumayyea Salahuddin
// Subject: 208-L Object Oriented Programming Lab, DCSE

#include <iostream>
using namespace std;

class shape{
    public:
        virtual void draw(){
            cout <<  "Draw shape" << endl;
        }
};

class circle: public shape{
    public:
        void draw(){
            cout << "Draw circle" << endl;
        }
};

class rectangle: public shape{
    public:
        void draw(){
            cout << "Draw rectangle" << endl;
        }
};

class triangle: public shape{
    public:
        void draw(){
            cout << "Draw triangle" << endl;
        }
};

int main(){
    shape *sh;
    circle c1; rectangle r1; triangle t1;

    sh = &c1;   sh->draw();
    sh = &r1;   sh->draw();
    sh = &t1;   sh->draw();

    return 0;
}

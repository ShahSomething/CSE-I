// Example: Friend Function example
// Author: Engr. Sumayyea Salahuddin
// Subject: 208-L Object Oriented Programming Lab, DCSE

#include <iostream>
using namespace std;

class A{
    private:
        int a;
    public:
        A():a(0){}
        A(int aa):a(aa){}
        void print(){ cout << "Number is: " << a << endl; }
        friend void update(A &obj);
};

void update(A &obj){
    obj.a = 5;
}

int main() {
    A aa(4);
    aa.print();
    update(aa);
    aa.print();

    return 0;
}

// Example: Friend Class example
// Author: Engr. Sumayyea Salahuddin
// Subject: 208-L Object Oriented Programming Lab, DCSE

#include <iostream>

using namespace std;

class A{
    private:
        int a;
        friend class B;
    public:
        A():a(0){}
        A(int aa):a(aa){}
        void showA(){ cout << "First number is: " << a<< endl;}
};

class B{
    private:
        int b;
    public:
        B():b(0){}
        B(int bb):b(bb){}
        void showB(A &objA){
            objA.a = 10;
            cout << "\nFirst number is: " << objA.a << endl;
            cout << "Second number is: " << b << endl;
        }
};

int main(){
    A aa(4);
    cout << "Showing A's data before B's: " << endl;
    aa.showA();

    B bb(7);
    bb.showB(aa);

    cout << "\nShowing A's data after B's: " << endl;
    aa.showA();

    return 0;
}

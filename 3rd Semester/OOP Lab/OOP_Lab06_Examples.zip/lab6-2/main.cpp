// Example: Multiple inheritance example
// Author: Engr. Sumayyea Salahuddin
// Subject: 208-L Object Oriented Programming Lab, DCSE

#include <iostream>

using namespace std;

class A{
    protected:
        int a;
    public:
        A():a(0){}
        A(int aa):a(aa){}
        void setA(int aa){ a = aa;}
        int getA(){ return a;}
        void print(){ cout << "First Number: " << a << endl;}
};

class B{
    protected:
        int b;
    public:
        B():b(0){}
        B(int bb):b(bb){}
        void setB(int bb){ b = bb;}
        int getB(){ return b;}
        void print(){ cout << "Second Number: " << b << endl;}
};

class C:public A,B{
    public:
        C(int a, int b){  setA(a); setB(b); }
        void print(){ A::print();  B::print(); }
};

int main()
{
    C cc(2,3);
    cc.print();

    return 0;
}

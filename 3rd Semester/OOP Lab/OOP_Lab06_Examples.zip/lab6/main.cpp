// Example: Multilevel inheritance example
// Author: Engr. Sumayyea Salahuddin
// Subject: 208-L Object Oriented Programming Lab, DCSE

#include <iostream>
using namespace std;

class A{
    protected:
        int a;
    public:
        A():a(0){}
        A(int aa):a(aa){}
        void setA(int aa){ a = aa; }
        int getA(){ return a;}
        void inputA(){ cout << "Enter first number: "; cin >> a;}
        void print(){ cout << "First number: " << a << endl; }
};

class B: public A{
    protected:
        int b;
    public:
        B():b(0),A(){}
        B(int bb):b(bb),A(){}
        B(int bb, int aa):b(bb),A(aa){}
        B(int bb, A aa){
            b = bb; a = aa.getA();
        }
        void setB(int bb){ b = bb;}
        int getB() { return b; }
        void inputB(){
            inputA();
            cout << "Enter second number: "; cin >> b;
        }
        void print(){
            A::print();
            cout << "Second number: " << b << endl;
        }
};

class C: public B{
    protected:
        int c;
    public:
        C():c(0),B(){}
        C(int cc):c(cc),B(){}
        C(int cc, int bb):c(cc),B(bb){}
        C(int cc, int bb, int aa):c(cc),B(bb,aa){}
        C(int cc, B bb){
            c = cc; b = bb.getB(); a = bb.getA();
        }
        void inputC(){
            inputB();
            cout << "Enter third number: "; cin >> c;
        }
        void print(){
            B::print();
            cout << "Third number: " << c << endl;
        }
};

int main()
{
    A aa;
    aa.inputA();
    aa.print();

    B bb;
    bb.inputB();
    bb.print();

    C cc;
    cc.inputC();
    cc.print();

    return 0;
}

// Example: Multifile Programming example
// Author: Engr. Sumayyea Salahuddin
// Subject: 208-L Object Oriented Programming Lab, DCSE

#include <iostream>
#include"C.h"

using namespace std;

int main(){
    C cc(2,3);
    cc.print();
    return 0;
}

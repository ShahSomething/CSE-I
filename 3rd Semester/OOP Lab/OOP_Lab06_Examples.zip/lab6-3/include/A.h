#ifndef A_H
#define A_H

class A {
    protected:
        int a;
    public:
        A();
        A(int aa);
        void setA(int aa);
        int getA();
        void print();
};

#endif // A_H

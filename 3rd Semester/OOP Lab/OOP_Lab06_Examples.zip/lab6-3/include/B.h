#ifndef B_H
#define B_H

class B {
    protected:
        int b;
    public:
        B();
        B(int bb);
        void setB(int bb);
        int getB();
        void print();
};

#endif // B_H

#ifndef C_H
#define C_H

#include"A.h"
#include"B.h"

class C:public A,B {
    public:
        C(int a, int b);
        void print();
};

#endif // C_H

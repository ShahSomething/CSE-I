#include "A.h"
#include<iostream>

A::A(){
    a = 0;
}

A::A(int aa){
    a = aa;
}

void A::setA(int aa){
    a = aa;
}

int A::getA(){
    return a;
}

void A::print(){
    std::cout << "First Number: " << a << std::endl;
}

#include "B.h"
#include<iostream>

B::B(){
    b = 0;
}

B::B(int bb){
    b = bb;
}

void B::setB(int bb){
    b = bb;
}

int B::getB(){
    return b;
}

void B::print(){
    std::cout << "Second Number: " << b << std::endl;
}

#include "C.h"

C::C(int a, int b){
    setA(a); setB(b);
}

void C::print(){
    A::print();  B::print();
}
